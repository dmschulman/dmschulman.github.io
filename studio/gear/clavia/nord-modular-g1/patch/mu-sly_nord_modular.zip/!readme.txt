Some patches for the Clavia Nord (Micro) Modular - I haven't had
this thing very long, but I've really got the bug at the moment.
I will definitely be making a lot more patches, and they're sure
to get better as I go on.  Still, I've been doing the conventional
synthesis thing for a while, so I'm not too bad right now!
Here's the best efforts so far (ie. the stuff I bothered to keep!)

* DiabolicalRave *

Calling all raving crew.... if it's phat, mean, raw and hardcore sounding
you're after then this baby should set you right up for that killer oldskool
or drum'n'bass anthem.

Inspired by the head-trashing rave synths of the early nineties hardcore
scene - just stick it over some Amen breaks and you'll find out what I'm on
about!  This is a class A substance... careful you don't overdose on it as
it's very addictive!  (One side effect of using it too much is that it makes
hours seem like minutes...)

OK the controls:

Mod-Wheel does hi-pass filter and resonance (for mid-tune breakdowns)

Aftertouch controls the detuning of the slave oscillators - good for the
"hoover" effect

Pitch bend - you get a full octave for those nasty acid flashback moments

Velocity controls the glide or smack effect at the start of each note (press
lightly to slowly glide into the note, or whack the keys to slice your head
off)

Want a left-right echo effect?  Well, this has about as good as you can get
from the modular - not a real echo, but it's faked using panning LFOs, and
it sounds pretty authentic.  Knob 1 controls dry/wet, knob 2 controls the
decay rate of the echo and knob 3 controls the delay time (echo rate).  I've
set it up with some pretty useful defaults but maybe you want something
different... no problem just tweak away!

I think that's about it.  I like this sound so much I think I might regret
giving it away, but you know, I like you guys, so it's no problem.  :-)

Most of all, have fun with it and let me know if it ends up anywhere
interesting!


* PhatBadMook *

This is quite a funky little patch - almost Minimoog sounding in my opinion
(but with a few extras bolted on NM stylee).  Anyway, it's great for jamming
away those funky basslines and due to it's low PVA usage, you can even
switch it up to get 3 note polyphony if you want to (although I think it
sounds funkier in monophonic).

The controls:

Velocity controls a number of things, but mainly the filter cutoff and
oscillator detuning - the harder you play, the fatter the sound gets.

Aftertouch controls more oscillator detuning, but also re-opens the filter
and the amplitude envelope.  As well as this, it speeds up an LFO which
modulates the pitch of one of the oscillators - all in all, pressing the
keys hard after you've played them makes the sound swell up again, and can
be used to get some smokin' funk riffs goin down.


* Crazy LFOs *

Pretty random crazy panning LFO fx - just play with it!


* Dillinjesque *

I just can't get enough of these Dillinja-style basses!
Pretty simple this one, so I don't think it needs much explaining.
The mod wheel controls the filter - can make some nice punchy or
growling sounds if you use it right!  I'll definitely improve
this sound at some point - might add some LFOs to modulate the
filter and make it auto-growl!

* RoadzKord *

A nice Rhodes chord for you - the chord is fixed, but you can
change the notes it plays by altering the slave oscillator tunings.
This samples really well.  Velocity controls the LFO rate for the autopan.
I just love this sound - it's so "nice" hehe!

* Winds Of Change *

According to my girlfriend, this sounds like "something dying!"
One of the first patches I made where I just went crazy and connected
everything to everything else just to see what would happen - I think
it sounds a bit like the wind outside during a storm.
Try putting headphones on and closing your eyes - the panning effect
is quite freaky!
Oh, and you have no control over this patch - it's got a mind of it's
own, just like the wind!


I hope you like my patches - keep coming back to the site, as they
will be added to all the time!

The rules for their use are simple: do what you like with them, but if
you do anything interesting with them, please let me know!  Thanks!

~Dave Silvester <sly@mu-sly.co.uk>
Web: http://www.mu-sly.co.uk/
