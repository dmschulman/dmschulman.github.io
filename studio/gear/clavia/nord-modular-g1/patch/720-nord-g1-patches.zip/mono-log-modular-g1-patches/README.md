# nord-modular-g1-patches
720 Nord Modular G1 patches, used in the daily blog uploads at: http://www.mono-log.org
